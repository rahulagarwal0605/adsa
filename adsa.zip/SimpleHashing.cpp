#include<bits/stdc++.h>
using namespace std;

class HashTable
{
    int table_size;
    list<int> *table;

public:
    HashTable(int size)
    {
        this->table_size = size;
        table = new list<int>[table_size];
    }

    void insert_item(int key)
    {
        int index = hash_function(key);
        table[index].push_back(key);
    }

    void delete_item(int key)
    {
        int index = hash_function(key);
        list <int> :: iterator i;
        for (i = table[index].begin(); i != table[index].end(); i++)
            if (*i == key)
                break;
        if (i != table[index].end())
            table[index].erase(i);
    }

    int hash_function(int key) {
        return (key % table_size);
    }

    void display_hash_table()
    {
        for (int i = 0; i < table_size; i++)
        {
            cout << i;
            for (auto x : table[i])
                cout << " --> " << x;
            cout << endl;
        }
    }
};

int main()
{
    vector<int> v = {15, 11, 27, 8, 12};
    int n = v.size();
    HashTable ht(7);
    for (int i = 0; i < n; i++)
        ht.insert_item(v[i]);
    ht.delete_item(12);
    ht.display_hash_table();
    return 0;
}
