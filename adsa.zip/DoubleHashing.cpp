#include <bits/stdc++.h>
using namespace std;
#define MAX_SIZE 10000001ll

class DoubleHash
{
    int table_size, keys_present, prime;
    vector<int> hash_table;
    bitset<MAX_SIZE> is_prime;

    void set_sieve()
    {
        is_prime[0] = is_prime[1] = 1;
        for (long long i = 2; i * i <= MAX_SIZE; i++)
            if (is_prime[i] == 0)
                for (long long j = i * i; j <= MAX_SIZE; j += i)
                    is_prime[j] = 1;

    }

    int inline hash1(int value)
    {
        return value % table_size;
    }

    int inline hash2(int value)
    {
        return prime - (value % prime);
    }

    bool inline is_full()
    {
        return (table_size == keys_present);
    }

public:
    DoubleHash(int n)
    {
        set_sieve();
        table_size = n;
        prime = table_size - 1;
        while (is_prime[prime] == 1)
            prime--;
        keys_present = 0;
        for (int i = 0; i < table_size; i++)
            hash_table.push_back(-1);
    }

    void print_prime(long long n)
    {
        for (long long i = 0; i <= n; i++)
            if (is_prime[i] == 0)
                cout << i << ", ";
        cout << endl;
    }

    void insert(int value)
    {
        if (value == -1 || value == -2)
        {
            cout << ("ERROR : -1 and -2 can't be inserted in the table\n");
        }
        if (is_full())
        {
            cout << ("ERROR : Hash Table Full\n");
            return;
        }
        int probe = hash1(value), offset = hash2(value);
        while (hash_table[probe] != -1)
        {
            if (-2 == hash_table[probe])
                break;
            probe = (probe + offset) % table_size;
        }
        hash_table[probe] = value;
        keys_present += 1;
    }

    void erase(int value)
    {
        if (!search(value))
            return;
        int probe = hash1(value), offset = hash2(value);
        while (hash_table[probe] != -1)
            if (hash_table[probe] == value)
            {
                hash_table[probe] = -2;
                keys_present--;
                return;
            }
            else
                probe = (probe + offset) % table_size;

    }

    bool search(int value)
    {
        int probe = hash1(value), offset = hash2(value), initialPos = probe;
        bool first_itr = true;
        while (1)
        {
            if (hash_table[probe] == -1)
                break;
            else if (hash_table[probe] == value)
                return true;
            else if (probe == initialPos && !first_itr)
                return false;
            else
                probe = ((probe + offset) % table_size);
            first_itr = false;
        }
        return false;
    }

    void print()
    {
        for (int i = 0; i < table_size; i++)
            cout << hash_table[i] << ", ";
        cout << "\n";
    }

};

int main() {
    DoubleHash dh(13);

    vector<int> insertions = {115, 12, 87, 66, 123};
    for (int i = 0; i < insertions.size(); i++)
        dh.insert(insertions[i]);
    cout << "Status of hash table after initial insertions : "; dh.print();

    vector<int> queries = {1, 12, 2, 3, 69, 88, 115};
    cout << "\n" << "Search operation after insertion : \n";
    for (int i = 0; i < queries.size(); i++)
        if (dh.search(queries[i]))
            cout << queries[i] << " present\n";
    cout << endl;

    vector<int> deletions = {123, 87, 66};
    for (int i = 0; i < deletions.size(); i++)
        dh.erase(deletions[i]);
    cout << "Status of hash table after deleting elements : "; dh.print();

    return 0;
}
