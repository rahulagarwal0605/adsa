#include <bits/stdc++.h>
using namespace std;

class Edge
{
public:
    int flow, capacity;
    int u, v;

    Edge(int flow, int capacity, int u, int v)
    {
        this->flow = flow;
        this->capacity = capacity;
        this->u = u;
        this->v = v;
    }
};

class Vertex
{
public:
    int height, excess_flow;

    Vertex(int height, int excess_flow)
    {
        this->height = height;
        this->excess_flow = excess_flow;
    }
};

class Graph
{
    int vertices;
    vector<Vertex> vertex_list;
    vector<Edge> edge_list;

    bool push(int u)
    {
        for (int i = 0; i < edge_list.size(); i++)
        {
            if (edge_list[i].u == u)
            {
                if (edge_list[i].flow == edge_list[i].capacity)
                    continue;
                if (vertex_list[u].height > vertex_list[edge_list[i].v].height)
                {
                    int flow = min(edge_list[i].capacity - edge_list[i].flow, vertex_list[u].excess_flow);
                    vertex_list[u].excess_flow -= flow;
                    vertex_list[edge_list[i].v].excess_flow += flow;
                    edge_list[i].flow += flow;
                    update_reverse_edge_flow(i, flow);
                    return true;
                }
            }
        }
        return false;
    }

    void relabel(int u)
    {
        int min_height = INT_MAX;
        for (int i = 0; i < edge_list.size(); i++)
        {
            if (edge_list[i].u == u)
            {
                if (edge_list[i].flow == edge_list[i].capacity)
                    continue;
                if (vertex_list[edge_list[i].v].height < min_height)
                {
                    min_height = vertex_list[edge_list[i].v].height;
                    vertex_list[u].height = min_height + 1;
                }
            }
        }
    }

    void preflow(int s)
    {
        vertex_list[s].height = vertex_list.size();
        for (int i = 0; i < edge_list.size(); i++)
        {
            if (edge_list[i].u == s)
            {
                edge_list[i].flow = edge_list[i].capacity;
                vertex_list[edge_list[i].v].excess_flow += edge_list[i].flow;
                edge_list.push_back(Edge(-edge_list[i].flow, 0, edge_list[i].v, s));
            }
        }
    }

    void update_reverse_edge_flow(int i, int flow)
    {
        int u = edge_list[i].v, v = edge_list[i].u;
        for (int j = 0; j < edge_list.size(); j++)
        {
            if (edge_list[j].v == v && edge_list[j].u == u)
            {
                edge_list[j].flow -= flow;
                return;
            }
        }
        Edge e = Edge(0, flow, u, v);
        edge_list.push_back(e);
    }

    int over_flow_vertex(vector<Vertex>& vertex_list)
    {
        for (int i = 1; i < vertex_list.size() - 1; i++)
            if (vertex_list[i].excess_flow > 0)
                return i;
        return -1;
    }


public:
    Graph(int vertices)
    {
        this->vertices = vertices;
        for (int i = 0; i < vertices; i++)
            vertex_list.push_back(Vertex(0, 0));
    }

    void add_edge(int u, int v, int capacity)
    {
        edge_list.push_back(Edge(0, capacity, u, v));
    }

    get_max_flow(int s, int t)
    {
        preflow(s);
        while (over_flow_vertex(vertex_list) != -1)
        {
            int u = over_flow_vertex(vertex_list);
            if (!push(u))
                relabel(u);
        }
        return vertex_list.back().excess_flow;
    }

};

int main()
{
    int vertices = 6;
    Graph g(vertices);

    g.add_edge(0, 1, 16);
    g.add_edge(0, 2, 13);
    g.add_edge(1, 2, 10);
    g.add_edge(2, 1, 4);
    g.add_edge(1, 3, 12);
    g.add_edge(2, 4, 14);
    g.add_edge(3, 2, 9);
    g.add_edge(3, 5, 20);
    g.add_edge(4, 3, 7);
    g.add_edge(4, 5, 4);

    int s = 0, t = 5;

    cout << "Maximum flow is " << g.get_max_flow(s, t);
    return 0;
}
